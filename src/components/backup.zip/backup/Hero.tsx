// Re-export the Hero component from sections to avoid duplication
export { default } from '../hero/Hero';
